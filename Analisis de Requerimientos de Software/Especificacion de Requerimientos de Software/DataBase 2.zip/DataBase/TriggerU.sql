CREATE DEFINER = CURRENT_USER TRIGGER `bam_banimals_adventure_db`.`USER_SCORE_BEFORE_UPDATE` BEFORE UPDATE ON `USER_SCORE` FOR EACH ROW
BEGIN
	IF coalesce(Bambastic) * 3 + coalesce(Noice) * 2 + coalesce(Keep_trying) * 1 + coalesce(Oops) * 0 > old.total_score THEN
		SET new.total_score = coalesce(Bambastic) * 3 + coalesce(Noice) * 2 + coalesce(Keep_trying) * 1 + coalesce(Oops) * 0;
	END IF;
END
