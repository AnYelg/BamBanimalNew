CREATE OR REPLACE VIEW MAX_HIGH_SCORE AS
-- Tablas a seleccionar
SELECT 
		Nickname, 
		Bambastic, 
        Noice, 
        Keep_trying, 
        Oops, 
        coalesce(Bambastic) * 3 as total_bambastic,
        coalesce(Noice) * 2 as total_noice,
        coalesce(Keep_trying)* 1 as total_KT,
        coalesce(Oops) * 0 as total_Oops,
        coalesce(Bambastic) * 3 + coalesce(Noice) * 2 + coalesce(Keep_trying) * 1 + coalesce(Oops) * 0 as Final_Score
        
        
-- Igualamos ambas tablas
FROM USER_SCORE US
INNER JOIN USER U ON U.id_USER = US.id_USER_SCORE 

-- Agrupar
ORDER BY Nickname
