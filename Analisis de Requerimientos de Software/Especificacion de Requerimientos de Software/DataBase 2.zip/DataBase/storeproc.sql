call get_attempt(1);
call get_score('Josh');